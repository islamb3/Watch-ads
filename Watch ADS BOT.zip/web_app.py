from flask import Flask, request, jsonify, render_template
from datetime import datetime, date
import json
from database import Database
from config import Config

app = Flask(__name__)
db = Database()
config = Config()

@app.route('/')
def home():
    return "AdPayBot Web Server is Running!"

@app.route('/webapp/<int:user_id>')
def web_app(user_id):
    """تطبيق الويب الرئيسي"""
    user_data = db.get_user(user_id)
    return render_template('index.html', user_data=json.dumps(user_data), user_id=user_id)

# واجهات برمجة التطبيقات (APIs)
@app.route('/api/user/<int:user_id>', methods=['GET'])
def get_user_data(user_id):
    """الحصول على بيانات المستخدم"""
    user_data = db.get_user(user_id)
    return jsonify(user_data)

@app.route('/api/watch_ad/<int:user_id>', methods=['POST'])
def watch_ad(user_id):
    """تسجيل مشاهدة إعلان"""
    user_data = db.get_user(user_id)
    today = date.today().isoformat()
    
    # التحقق من الحد اليومي
    if user_data.get('last_ad_date') != today:
        user_data['daily_ad_count'] = 0
        user_data['last_ad_date'] = today
    
    if user_data['daily_ad_count'] >= config.MAX_ADS_PER_DAY:
        return jsonify({'success': False, 'message': 'تم الوصول للحد اليومي'})
    
    # تحديث البيانات
    user_data['daily_ad_count'] += 1
    user_data['total_watched'] += 1
    user_data['ad_earnings'] += config.AD_REWARD
    user_data['balance'] += config.AD_REWARD
    
    # منح مكافأة 250 إعلان
    if user_data['total_watched'] >= 250 and not user_data.get('bonus_250_given'):
        user_data['bonus_250_given'] = True
        user_data['balance'] += 0.01
        user_data['ad_earnings'] += 0.01
    
    db.save_user(user_id, user_data)
    
    return jsonify({
        'success': True,
        'reward': config.AD_REWARD,
        'new_balance': user_data['balance'],
        'daily_count': user_data['daily_ad_count']
    })

@app.route('/api/daily_reward/<int:user_id>', methods=['POST'])
def claim_daily_reward(user_id):
    """المطالبة بالمكافأة اليومية"""
    user_data = db.get_user(user_id)
    today = date.today().isoformat()
    
    if user_data.get('last_daily_reward') == today:
        return jsonify({'success': False, 'message': 'تم المطالبة بالمكافأة اليومية مسبقاً'})
    
    user_data['last_daily_reward'] = today
    user_data['balance'] += config.DAILY_REWARD
    user_data['ad_earnings'] += config.DAILY_REWARD
    
    db.save_user(user_id, user_data)
    
    return jsonify({
        'success': True,
        'reward': config.DAILY_REWARD,
        'new_balance': user_data['balance']
    })

@app.route('/api/withdraw/<int:user_id>', methods=['POST'])
def request_withdrawal(user_id):
    """طلب سحب الأرباح"""
    data = request.json
    amount = float(data.get('amount', 0))
    address = data.get('address', '')
    
    user_data = db.get_user(user_id)
    
    if amount < config.MIN_WITHDRAWAL:
        return jsonify({'success': False, 'message': f'الحد الأدنى للسحب هو {config.MIN_WITHDRAWAL} TON'})
    
    if amount > user_data['balance']:
        return jsonify({'success': False, 'message': 'الرصيد غير كافي'})
    
    if not address:
        return jsonify({'success': False, 'message': 'يرجى إدخال عنوان المحفظة'})
    
    # إضافة طلب السحب
    withdrawal = db.add_withdrawal(user_id, amount, address)
    
    return jsonify({
        'success': True,
        'withdrawal_id': withdrawal['id'],
        'new_balance': user_data['balance'] - amount
    })

@app.route('/api/apply_referral/<int:user_id>', methods=['POST'])
def apply_referral_code(user_id):
    """تطبيق كود الإحالة"""
    data = request.json
    referral_code = data.get('code', '')
    
    if not referral_code:
        return jsonify({'success': False, 'message': 'يرجى إدخال كود الإحالة'})
    
    try:
        referral_id = int(referral_code)
    except ValueError:
        return jsonify({'success': False, 'message': 'كود الإحالة غير صالح'})
    
    user_data = db.get_user(user_id)
    
    if user_data.get('referred_by'):
        return jsonify({'success': False, 'message': 'تم استخدام كود إحالة مسبقاً'})
    
    if referral_id == user_id:
        return jsonify({'success': False, 'message': 'لا يمكن استخدام كود الإحالة الخاص بك'})
    
    # التحقق من وجود المُحيل
    referrer_data = db.get_user(referral_id)
    if not referrer_data:
        return jsonify({'success': False, 'message': 'كود الإحالة غير موجود'})
    
    # تطبيق الإحالة
    db.add_referral(referral_id, user_id)
    
    return jsonify({'success': True, 'message': 'تم تطبيق كود الإحالة بنجاح!'})

if __name__ == '__main__':
    app.run(host=config.WEBAPP_HOST, port=config.WEBAPP_PORT, debug=True)
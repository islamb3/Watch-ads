# AdPayBot - Telegram Ad Watching Bot

A complete Telegram bot for watching ads and earning TON cryptocurrency.

## Features
- Watch ads and earn TON
- Daily rewards system
- Referral program
- Withdrawal system
- Admin panel
- Web application

## Deployment on Zeabur

1. Fork this repository
2. Connect to Zeabur
3. Set environment variables:
   - `BOT_TOKEN`: Your Telegram bot token
   - `BOT_USERNAME`: Your bot username
   - `ADMIN_IDS`: Comma-separated admin user IDs

## Environment Variables
- `BOT_TOKEN`: Telegram Bot Token from @BotFather
- `BOT_USERNAME`: Your bot username
- `ADMIN_IDS`: Admin user IDs (comma separated)
- `ZEABUR_DEPLOYMENT`: Set to `true` for production
import os
import threading
import time
from bot import AdPayBot
from web_app import app as web_app
from admin_panel import app as admin_app

def run_bot():
    """تشغيل البوت في thread منفصل"""
    try:
        bot = AdPayBot()
        print("🤖 Starting Telegram Bot...")
        bot.run()
    except Exception as e:
        print(f"❌ Bot Error: {e}")

def run_web_app():
    """تشغيل تطبيق الويب"""
    try:
        port = int(os.getenv('PORT', 5000))
        print(f"🌐 Starting Web App on port {port}...")
        web_app.run(host='0.0.0.0', port=port, debug=False, use_reloader=False)
    except Exception as e:
        print(f"❌ Web App Error: {e}")

def run_admin_panel():
    """تشغيل لوحة التحكم"""
    try:
        admin_port = int(os.getenv('ADMIN_PORT', 5001))
        print(f"🛠 Starting Admin Panel on port {admin_port}...")
        admin_app.run(host='0.0.0.0', port=admin_port, debug=False, use_reloader=False)
    except Exception as e:
        print(f"❌ Admin Panel Error: {e}")

if __name__ == '__main__':
    print("🚀 Starting AdPayBot System...")
    print("=" * 50)
    
    # تشغيل البوت في thread منفصل
    bot_thread = threading.Thread(target=run_bot)
    bot_thread.daemon = True
    bot_thread.start()
    
    # انتظار قليل لبدء البوت
    time.sleep(2)
    
    # في Zeabur، سنشغل تطبيق ويب واحد فقط
    if os.getenv('ZEABUR_DEPLOYMENT'):
        print("🚀 Running in Zeabur environment...")
        run_web_app()
    else:
        # تشغيل تطبيقات الويب في التطوير المحلي
        web_thread = threading.Thread(target=run_web_app)
        web_thread.daemon = True
        web_thread.start()
        
        admin_thread = threading.Thread(target=run_admin_panel)
        admin_thread.daemon = True
        admin_thread.start()
        
        print("\n✅ All systems are running!")
        print("📱 Web App: http://localhost:5000")
        print("🛠 Admin Panel: http://localhost:5001/admin")
        print("🤖 Bot: Running in background")
        print("=" * 50)
        print("Press Ctrl+C to stop all services")
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 Shutting down AdPayBot System...")
            print("👋 Goodbye!")
import os
from web_app import app as web_app
from admin_panel import app as admin_app
from flask import Flask, redirect

# تطبيق رئيسي للتوجيه
main_app = Flask(__name__)

@main_app.route('/')
def home():
    return redirect('/webapp/demo')

@main_app.route('/admin')
def admin_redirect():
    return redirect('/admin/login')

# دمج التطبيقات (هذا مثال مبسط، في الإنتاج قد تحتاج لتعديل)
if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    print(f"🚀 Starting AdPayBot on port {port}...")
    web_app.run(host='0.0.0.0', port=port, debug=False)
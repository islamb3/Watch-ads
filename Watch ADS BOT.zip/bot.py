import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from database import Database
from config import Config

# إعداد التسجيل
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

class AdPayBot:
    def __init__(self):
        self.db = Database()
        self.config = Config()
        self.application = Application.builder().token(self.config.BOT_TOKEN).build()
        self._setup_handlers()
    
    def _setup_handlers(self):
        """إعداد معالجات الأوامر"""
        self.application.add_handler(CommandHandler("start", self.start))
        self.application.add_handler(CommandHandler("stats", self.stats))
        self.application.add_handler(CommandHandler("admin", self.admin_panel))
        self.application.add_handler(CallbackQueryHandler(self.button_handler))
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج أمر البدء"""
        user = update.effective_user
        user_id = user.id
        
        # التحقق من الإحالة
        referral_id = None
        if context.args:
            try:
                referral_id = int(context.args[0])
                if referral_id != user_id:  # منع الإحالة الذاتية
                    self.db.add_referral(referral_id, user_id)
            except ValueError:
                pass
        
        # الحصول على بيانات المستخدم
        user_data = self.db.get_user(user_id)
        
        # إنشاء رابط تطبيق الويب
        web_app_url = f"https://{context.bot.username}.herokuapp.com/webapp/{user_id}"
        
        # رسالة الترحيب
        welcome_text = f"""
🎉 **مرحباً {user.first_name}!**

💰 **AdPayBot** - شاهد الإعلانات واربح TON

📊 **إحصائياتك:**
├ الرصيد: `{user_data['balance']:.6f} TON`
├ أرباح الإعلانات: `{user_data['ad_earnings']:.6f} TON`
├ أرباح الإحالات: `{user_data['referral_earnings']:.6f} TON`
├ الإعلانات المشاهدة: `{user_data['total_watched']}`
├ الإحالات: `{user_data['total_referrals']}`
└ المسحوب: `{user_data['total_withdrawn']:.6f} TON`

🎁 **مكافأة يومية:** 0.002 TON
📺 **ربح لكل إعلان:** 0.0002 TON
👥 **ربح لكل إحالة:** 0.002 TON

🚀 **لبدء الربح، اضغط على الزر أدناه لفتح التطبيق!**
        """
        
        keyboard = [
            [InlineKeyboardButton("📱 فتح التطبيق", web_app={"url": web_app_url})],
            [InlineKeyboardButton("👥 رابط الإحالة", callback_data="referral_link")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            welcome_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    
    async def stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """عرض الإحصائيات"""
        user_id = update.effective_user.id
        user_data = self.db.get_user(user_id)
        
        stats_text = f"""
📊 **إحصائياتك الشخصية**

💰 الرصيد: `{user_data['balance']:.6f} TON`
📺 إجمالي المشاهدات: `{user_data['total_watched']}`
👥 الإحالات النشطة: `{user_data['total_referrals']}`
💸 المسحوب: `{user_data['total_withdrawn']:.6f} TON`

🎯 التقدم اليومي: `{user_data['daily_ad_count']}/{self.config.MAX_ADS_PER_DAY}`
        """
        
        await update.message.reply_text(stats_text, parse_mode='Markdown')
    
    async def admin_panel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """لوحة التحكم الإدارية"""
        user_id = update.effective_user.id
        
        if not self.db.is_admin(user_id):
            await update.message.reply_text("❌ ليس لديك صلاحية للوصول إلى لوحة التحكم.")
            return
        
        stats = self.db.get_system_stats()
        admin_text = f"""
🛠 **لوحة التحكم الإدارية**

👥 إجمالي المستخدمين: `{stats['total_users']}`
💰 إجمالي الرصيد: `{stats['total_balance']:.6f} TON`
📺 إجمالي المشاهدات: `{stats['total_ads_watched']}`
💸 إجمالي المسحوب: `{stats['total_withdrawn']:.6f} TON`
🎯 النشطون اليوم: `{stats['active_today']}`
        """
        
        keyboard = [
            [InlineKeyboardButton("📊 الإحصائيات", callback_data="admin_stats")],
            [InlineKeyboardButton("👥 إدارة المستخدمين", callback_data="admin_users")],
            [InlineKeyboardButton("⚙️ الإعدادات", callback_data="admin_settings")],
            [InlineKeyboardButton("🌐 لوحة الويب", url=f"https://{context.bot.username}.herokuapp.com/admin")]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(admin_text, reply_markup=reply_markup, parse_mode='Markdown')
    
    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج الأزرار"""
        query = update.callback_query
        await query.answer()
        
        user_id = query.from_user.id
        
        if query.data == "referral_link":
            referral_link = f"https://t.me/{context.bot.username}?start={user_id}"
            await query.edit_message_text(
                f"🔗 **رابط الإحالة الخاص بك:**\n\n`{referral_link}`\n\n"
                f"📤 شارك هذا الرابط مع أصدقائك لتحصل على 0.002 TON لكل شخص يسجل عبره!",
                parse_mode='Markdown'
            )
        
        elif query.data.startswith("admin_"):
            if not self.db.is_admin(user_id):
                await query.edit_message_text("❌ ليس لديك صلاحية للوصول إلى هذه الصفحة.")
                return
            
            if query.data == "admin_stats":
                stats = self.db.get_system_stats()
                stats_text = f"""
📊 **إحصائيات النظام**

👥 إجمالي المستخدمين: `{stats['total_users']}`
💰 إجمالي الرصيد: `{stats['total_balance']:.6f} TON`
📺 إجمالي المشاهدات: `{stats['total_ads_watched']}`
💸 إجمالي المسحوب: `{stats['total_withdrawn']:.6f} TON`
🎯 النشطون اليوم: `{stats['active_today']}`
                """
                await query.edit_message_text(stats_text, parse_mode='Markdown')
    
    def run(self):
        """تشغيل البوت"""
        self.application.run_polling()

if __name__ == '__main__':
    bot = AdPayBot()
    bot.run()
import json
import os
from datetime import datetime, date
from typing import Dict, Any, List

class Database:
    def __init__(self):
        self.data_dir = "data"
        self.users_file = os.path.join(self.data_dir, "users.json")
        self.admins_file = os.path.join(self.data_dir, "admins.json")
        self.settings_file = os.path.join(self.data_dir, "settings.json")
        self._ensure_data_dir()
        self._initialize_files()
    
    def _ensure_data_dir(self):
        """إنشاء مجلد البيانات إذا لم يكن موجوداً"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
    
    def _initialize_files(self):
        """تهيئة ملفات JSON إذا لم تكن موجودة"""
        defaults = {
            self.users_file: {},
            self.admins_file: [],
            self.settings_file: {
                "ad_reward": 0.0002,
                "daily_reward": 0.002,
                "referral_reward": 0.002,
                "min_withdrawal": 0.1,
                "max_ads_per_day": 250
            }
        }
        
        for file_path, default_data in defaults.items():
            if not os.path.exists(file_path):
                self._save_json(file_path, default_data)
    
    def _load_json(self, file_path: str) -> Any:
        """تحميل بيانات من ملف JSON"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
    
    def _save_json(self, file_path: str, data: Any):
        """حفظ بيانات إلى ملف JSON"""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Error saving to {file_path}: {e}")
            return False
    
    # إدارة المستخدمين
    def get_user(self, user_id: int) -> Dict[str, Any]:
        """الحصول على بيانات المستخدم"""
        users = self._load_json(self.users_file)
        user_data = users.get(str(user_id))
        
        if not user_data:
            # إنشاء مستخدم جديد
            user_data = {
                "user_id": user_id,
                "balance": 0.0,
                "ad_earnings": 0.0,
                "referral_earnings": 0.0,
                "total_watched": 0,
                "daily_ad_count": 0,
                "total_referrals": 0,
                "total_withdrawn": 0.0,
                "last_ad_date": None,
                "last_daily_reward": None,
                "referred_by": None,
                "withdrawals": [],
                "joined_date": datetime.now().isoformat(),
                "bonus_250_given": False
            }
            self.save_user(user_id, user_data)
        
        return user_data
    
    def save_user(self, user_id: int, user_data: Dict[str, Any]):
        """حفظ بيانات المستخدم"""
        users = self._load_json(self.users_file)
        users[str(user_id)] = user_data
        return self._save_json(self.users_file, users)
    
    def get_all_users(self) -> Dict[str, Any]:
        """الحصول على جميع المستخدمين"""
        return self._load_json(self.users_file)
    
    # إدارة الإحالات
    def add_referral(self, referrer_id: int, referred_id: int):
        """إضافة إحالة جديدة"""
        referrer = self.get_user(referrer_id)
        referred = self.get_user(referred_id)
        
        # تحديث بيانات المُحيل
        referrer["total_referrals"] += 1
        referrer["referral_earnings"] += 0.002
        referrer["balance"] += 0.002
        
        # تحديث بيانات المُحال
        referred["referred_by"] = referrer_id
        
        self.save_user(referrer_id, referrer)
        self.save_user(referred_id, referred)
    
    # إدارة السحوبات
    def add_withdrawal(self, user_id: int, amount: float, address: str):
        """إضافة طلب سحب جديد"""
        user = self.get_user(user_id)
        
        withdrawal = {
            "id": f"W{datetime.now().timestamp()}",
            "amount": amount,
            "address": address,
            "status": "pending",
            "requested_at": datetime.now().isoformat(),
            "available_at": (datetime.now().timestamp() + 24 * 3600) * 1000
        }
        
        user["withdrawals"].append(withdrawal)
        user["balance"] -= amount
        
        self.save_user(user_id, user)
        return withdrawal
    
    # إدارة الإعدادات
    def get_settings(self) -> Dict[str, Any]:
        """الحصول على إعدادات النظام"""
        return self._load_json(self.settings_file)
    
    def update_settings(self, new_settings: Dict[str, Any]):
        """تحديث إعدادات النظام"""
        current_settings = self.get_settings()
        current_settings.update(new_settings)
        return self._save_json(self.settings_file, current_settings)
    
    # إدارة المديرين
    def get_admins(self) -> List[int]:
        """الحصول على قائمة المديرين"""
        return self._load_json(self.admins_file)
    
    def is_admin(self, user_id: int) -> bool:
        """التحقق إذا كان المستخدم مدير"""
        return user_id in self.get_admins()
    
    def add_admin(self, user_id: int):
        """إضافة مدير جديد"""
        admins = self.get_admins()
        if user_id not in admins:
            admins.append(user_id)
            return self._save_json(self.admins_file, admins)
        return False
    
    def remove_admin(self, user_id: int):
        """إزالة مدير"""
        admins = self.get_admins()
        if user_id in admins:
            admins.remove(user_id)
            return self._save_json(self.admins_file, admins)
        return False
    
    # إحصائيات النظام
    def get_system_stats(self) -> Dict[str, Any]:
        """الحصول على إحصائيات النظام"""
        users = self.get_all_users()
        total_users = len(users)
        total_balance = sum(user["balance"] for user in users.values())
        total_ads_watched = sum(user["total_watched"] for user in users.values())
        total_withdrawn = sum(user["total_withdrawn"] for user in users.values())
        
        return {
            "total_users": total_users,
            "total_balance": total_balance,
            "total_ads_watched": total_ads_watched,
            "total_withdrawn": total_withdrawn,
            "active_today": len([u for u in users.values() 
                               if u.get("last_ad_date") == date.today().isoformat()])
        }
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from database import Database
from config import Config
import json

app = Flask(__name__)
app.secret_key = 'islam@'  # تغيير هذا في الإنتاج
db = Database()
config = Config()

def require_admin(f):
    """مصادقة المديرين"""
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session or not db.is_admin(session['admin_id']):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """تسجيل دخول المدير"""
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        password = request.form.get('password')  # في الإنتاج، استخدم مصادقة آمنة
        
        try:
            user_id = int(user_id)
            if db.is_admin(user_id):  # في الإنتاج، تحقق من كلمة المرور
                session['admin_id'] = user_id
                return redirect(url_for('admin_dashboard'))
        except ValueError:
            pass
        
        return render_template('admin_login.html', error='بيانات الدخول غير صحيحة')
    
    return render_template('admin_login.html')

@app.route('/admin')
@require_admin
def admin_dashboard():
    """لوحة التحكم الرئيسية"""
    stats = db.get_system_stats()
    users = db.get_all_users()
    
    # المستخدمون النشطون (آخر 7 أيام)
    recent_users = sorted(
        [u for u in users.values() if u.get('joined_date')],
        key=lambda x: x.get('joined_date', ''),
        reverse=True
    )[:10]
    
    return render_template('admin_dashboard.html', 
                         stats=stats, 
                         recent_users=recent_users,
                         settings=db.get_settings())

@app.route('/admin/users')
@require_admin
def admin_users():
    """إدارة المستخدمين"""
    users = db.get_all_users()
    return render_template('admin_users.html', users=users)

@app.route('/admin/user/<int:user_id>')
@require_admin
def user_details(user_id):
    """تفاصيل المستخدم"""
    user_data = db.get_user(user_id)
    return jsonify(user_data)

@app.route('/admin/update_user/<int:user_id>', methods=['POST'])
@require_admin
def update_user(user_id):
    """تحديث بيانات المستخدم"""
    data = request.json
    user_data = db.get_user(user_id)
    
    # تحديث الحقول المسموح بها
    allowed_fields = ['balance', 'ad_earnings', 'referral_earnings', 'total_watched', 'total_referrals']
    for field in allowed_fields:
        if field in data:
            user_data[field] = float(data[field]) if 'earnings' in field or 'balance' in field else int(data[field])
    
    db.save_user(user_id, user_data)
    return jsonify({'success': True})

@app.route('/admin/settings', methods=['GET', 'POST'])
@require_admin
def admin_settings():
    """إعدادات النظام"""
    if request.method == 'POST':
        new_settings = {
            'ad_reward': float(request.form.get('ad_reward', 0.0002)),
            'daily_reward': float(request.form.get('daily_reward', 0.002)),
            'referral_reward': float(request.form.get('referral_reward', 0.002)),
            'min_withdrawal': float(request.form.get('min_withdrawal', 0.1)),
            'max_ads_per_day': int(request.form.get('max_ads_per_day', 250))
        }
        
        db.update_settings(new_settings)
        return redirect(url_for('admin_settings'))
    
    settings = db.get_settings()
    return render_template('admin_settings.html', settings=settings)

@app.route('/admin/withdrawals')
@require_admin
def admin_withdrawals():
    """إدارة طلبات السحب"""
    users = db.get_all_users()
    withdrawals = []
    
    for user_id, user_data in users.items():
        for withdrawal in user_data.get('withdrawals', []):
            withdrawal['user_id'] = user_id
            withdrawal['user_name'] = f"User {user_id}"
            withdrawals.append(withdrawal)
    
    # ترتيب بحسب التاريخ
    withdrawals.sort(key=lambda x: x.get('requested_at', ''), reverse=True)
    
    return render_template('admin_withdrawals.html', withdrawals=withdrawals)

@app.route('/admin/update_withdrawal/<withdrawal_id>', methods=['POST'])
@require_admin
def update_withdrawal(withdrawal_id):
    """تحديث حالة السحب"""
    status = request.json.get('status')
    
    users = db.get_all_users()
    for user_id, user_data in users.items():
        for withdrawal in user_data.get('withdrawals', []):
            if withdrawal.get('id') == withdrawal_id:
                withdrawal['status'] = status
                if status == 'paid':
                    user_data['total_withdrawn'] += withdrawal['amount']
                db.save_user(int(user_id), user_data)
                return jsonify({'success': True})
    
    return jsonify({'success': False, 'message': 'طلب السحب غير موجود'})

@app.route('/admin/broadcast', methods=['GET', 'POST'])
@require_admin
def admin_broadcast():
    """بث رسالة للمستخدمين"""
    if request.method == 'POST':
        message = request.form.get('message')
        # هنا يمكنك إضافة كود لإرسال الرسالة لجميع المستخدمين عبر البوت
        return jsonify({'success': True, 'message': 'تم إرسال الرسالة'})
    
    return render_template('admin_broadcast.html')

@app.route('/admin/logout')
def admin_logout():
    """تسجيل خروج المدير"""
    session.pop('admin_id', None)
    return redirect(url_for('admin_login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
    
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # إعدادات البوت
    BOT_TOKEN = os.getenv('BOT_TOKEN', '8287161764:AAG4kqQp6m2awPoyZSZweLifGxZ1TrcqkVU')
    BOT_USERNAME = os.getenv('BOT_USERNAME', 'watch_ads_0bot')
    
    # إعدادات الويب
    WEBAPP_HOST = os.getenv('WEBAPP_HOST', '0.0.0.0')
    WEBAPP_PORT = int(os.getenv('PORT', 5000))  # Zeabur يستخدم PORT
    
    # إعدادات الإدارة
    ADMIN_IDS = [int(x) for x in os.getenv('ADMIN_IDS', '1955531856').split(',')]
    
    # إعدادات الأرباح
    AD_REWARD = 0.0002
    DAILY_REWARD = 0.002
    REFERRAL_REWARD = 0.002
    MIN_WITHDRAWAL = 0.1
    MAX_ADS_PER_DAY = 250    